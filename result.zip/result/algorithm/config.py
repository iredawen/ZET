
def Time_begin():
    time_config =[
        0, 4.7, 16.4
    ] 
    return time_config

def Station_begin():
    station_config =[
        1, 2
    ] 
    return station_config
